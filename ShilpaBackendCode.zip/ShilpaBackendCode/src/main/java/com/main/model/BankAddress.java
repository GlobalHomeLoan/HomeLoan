package com.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import javax.validation.constraints.Max;
import javax.validation.constraints.Min;

@Entity
public class BankAddress {
	@GeneratedValue(strategy=GenerationType.SEQUENCE)
	@Id
	private int bankAddId;
	private String area;
	@NotBlank(message = "City cannot be empty")
	private String city;
	@Min(message="pin code should be of 6 digits", value=100000)
	@Max(message="pin code should be of 6 digits", value=999999)
	private int pin;
	@NotBlank(message = "State cannot be empty")
	private  String state;
	public int getBankAddId() {
		return bankAddId;
	}
	public void setBankAddId(int bankAddId) {
		this.bankAddId = bankAddId;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	

}
