package com.main.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;
import com.main.Service.InterfaceService;
import com.main.model.CurrentLoan;


@CrossOrigin("*")
@RestController
public class LoanController {
	@Autowired
	InterfaceService service;
	
	@PostMapping("/saveCurrentLoanData")
	public CurrentLoan saveLoanData(@Valid @RequestBody CurrentLoan cl)
	{
		System.out.println(">>>>>>>>>>>"+ cl.getCurrentloanNo());
		System.out.println(">>>>>>>>>>>"+ cl.getLoanAmount());
		System.out.println(">>>>>>>>>>>"+ cl.getRateOfInterest());
		System.out.println(">>>>>>>>>>>"+ cl.getTenure());
		System.out.println(">>>>>>>>>>>"+ cl.getProcessingFees());
		System.out.println(">>>>>>>>>>>"+ cl.getTotalInterest());
		if(cl.getCurrentloanId()==0){
		CurrentLoan loan=service.saveData(cl);
		return loan;
		}
		else {
			System.out.println("inside loan controller else part");
			CurrentLoan loan=service.updateData(cl);
			return loan;
		}
	}
	@GetMapping("/getCurrentLoanData")
	public List<CurrentLoan> getLoanData()
	{
		List<CurrentLoan> loanList=service.getData();
		return loanList;
	}
	@PutMapping("/updateCurrentLoanData")
	public CurrentLoan updateLoanData(@Valid @RequestBody CurrentLoan cl)
	{
		CurrentLoan loan=service.updateData(cl);
		return loan;
	}
	@DeleteMapping("/deleteCurrentLoanData/{currentloanId}")
	public void deleteLoanData(@PathVariable int currentloanId)
	{
		service.deleteData(currentloanId);
		
	}
	
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, String> handleValidationExceptions(
	  MethodArgumentNotValidException ex) {
		System.out.println("inside excepton handling");
	    Map<String, String> errors = new HashMap<>();
	    ex.getBindingResult().getAllErrors().forEach((error) -> {
	        String fieldName = ((FieldError) error).getField();
	        String errorMessage = error.getDefaultMessage();
	        errors.put(fieldName, errorMessage);
	    });
	    return errors;
	}
}
	
	  	
	
	