package com.main.Service;

import java.util.List;

import com.main.model.Cibil;


public interface InterfaceCibilService {
	public Cibil saveData(Cibil a);
	public List<Cibil> getData();
	public Cibil updateData(Cibil a);
	public void deleteData(int id);
	
}
