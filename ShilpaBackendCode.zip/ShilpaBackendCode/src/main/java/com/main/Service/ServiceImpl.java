package com.main.Service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.main.model.CurrentLoan;
import com.main.repository.CurrentLoanRepo;


@Service
public class ServiceImpl implements InterfaceService {
	@Autowired
	CurrentLoanRepo loanRepo;

	@Override
	public CurrentLoan saveData(CurrentLoan cl) {
		System.out.println("inside ServiceImpl  save");
		CurrentLoan loan=loanRepo.save(cl);
		return loan;
	}

	@Override
	public List<CurrentLoan> getData() {
		List<CurrentLoan> loanList=loanRepo.findAll();
		return loanList;
	}

	@Override
	public CurrentLoan updateData(CurrentLoan a) {
		
		return loanRepo.save(a);
	}

	@Override
	public void deleteData(int id) {
		loanRepo.deleteById(id);
		
	}

		

}
