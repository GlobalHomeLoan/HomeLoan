package com.main.Service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

@Service
public class EmailSendingService {
	@Autowired
	public JavaMailSender javamailsender;
	
	public void send(int cibilScore)
	{
		SimpleMailMessage m=new SimpleMailMessage();
		m.setTo("springdemo86@gmail.com");
		
		if(cibilScore <= 700) {
			m.setSubject("Sorry we cannot approve your loan");
			m.setText("Sorry we cannot approve your loan as your cibil score is Too Low " + cibilScore);
		} else {
			m.setSubject("We are glad to offer you loan");
			m.setText("We are glad to offer you loan . Your cibil score is "+cibilScore);
		}
		
		javamailsender.send(m);
		
	}
}
