package com.main.Service;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.main.LowCibilScoreException;
import com.main.model.Cibil;
import com.main.repository.CibilRepo;


@Service
public class CibilServiceImpl implements InterfaceCibilService {
	@Autowired
	CibilRepo repo;
	@Autowired
	EmailSendingService emailSendingService;

	@Override
	public Cibil saveData(Cibil a) {
		Random random=new Random();
		int randomCibilScore = random.nextInt(750-650)+650;
		emailSendingService.send(randomCibilScore);
		if (randomCibilScore <= 700) {
			throw new LowCibilScoreException("You have low cibil Score"+randomCibilScore);
		}
		a.setCibilScore(randomCibilScore);
		Cibil cibil=repo.save(a);
		return cibil;
	}

	@Override
	public List<Cibil> getData() {
		List<Cibil> clist=repo.findAll();
		return clist;
	}

	@Override
	public Cibil updateData(Cibil a) {
		return repo.save(a);
	}

	@Override
	public void deleteData(int id) {
		repo.deleteById(id);
		
	}

	
}
