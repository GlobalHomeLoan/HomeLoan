package com.main.Service;

import java.util.List;

import com.main.model.CurrentLoan;

public interface InterfaceService {
	public CurrentLoan saveData(CurrentLoan a);
	public List<CurrentLoan> getData();
	public CurrentLoan updateData(CurrentLoan a);
	public void deleteData(int id);
	
}
