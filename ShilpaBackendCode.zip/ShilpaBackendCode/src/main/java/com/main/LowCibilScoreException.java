package com.main;

public class LowCibilScoreException extends RuntimeException{
	
	public LowCibilScoreException(String msg) {
		super(msg);
	}

}
