import { Injectable } from '@angular/core';
import { Sanction } from '../model/sanction';
import { HttpClient } from '@angular/common/http';
import { Email } from '../model/email';

@Injectable({
  providedIn: 'root'
})
export class SanctionService {

  constructor(private http:HttpClient) { }

  sanctionLetter:Sanction={
    sanctionId: 0,
    sanctionDate: '',
    applicantName: '',
    contactDetails: '',
    producthomeEquity: '',
    loanAmtSanctioned: '',
    interestType: '',
    rateOfInterest: '',
    loanTenure: '',
    monthlyEmiAmount: '',
    modeOfPayment: '',
    remarks: '',
    termsCondition: '',
    status: ''
  }

  saveSanctionDataDemo(s:Sanction)
  {
    return this.http.post("http://localhost:9090/saveSanctionLetter",s);
  }

  getSanctionDataDemo()
  {
    return this.http.get("http://localhost:9090/getAllSanctionLetter");
  }

  savemaildemo(m:Email)
  {
    return this.http.post("http://localhost:9090/sendemail",m);
  }
}
