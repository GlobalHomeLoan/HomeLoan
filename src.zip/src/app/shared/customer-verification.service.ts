import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CustomerVerification } from '../model/customer-verification';

@Injectable({
  providedIn: 'root'
})
export class CustomerVerificationService {

  constructor(private http:HttpClient) { }

  customer:CustomerVerification={
    verificationId: 0,
    verificationDate: '',
    status: '',
    remarks: ''
  }


  saveCustomerVerificationDemo(a:CustomerVerification)
  {
    return this.http.post("http://localhost:9090/saveVerification",a);
  }

  getCustomerVerificationDemo()
  {
    return this.http.get("http://localhost:9090/getAllCustVerification");
  }
}
