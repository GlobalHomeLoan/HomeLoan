import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { AccountDetails } from '../model/account-details';

@Injectable({
  providedIn: 'root'
})
export class AccountDetailsService {

  constructor(private http:HttpClient) { }

  account:AccountDetails={
    accountId: 0,
    accountType: '',
    accountBalance: '',
    accountHolderName: '',
    accountStatus: '',
    accountNumber: '',
    branchName: '',
    branchCode: '',
    branchType: '',
    iFSCcode: '',
    mICRcode: '',
    conatctNumber: '',
    email: '',
    bankAddress:{
      bankAddrId: 0,
	    area: '',
	    city: '',
	    pin: '',
	    state: '',
    }
  }

  saveAccountDetailsDemo(a:AccountDetails)
  {
    return this.http.post("http://localhost:9090/saveAccDetails",a);
  }

  getAccountDetailsDemo()
  {
    return this.http.get("http://localhost:9090/getAllAccDetails");
  }
}
