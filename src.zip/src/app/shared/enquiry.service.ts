import { Injectable } from '@angular/core';
import { Enquiry } from '../model/enquiry';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class EnquiryService {

  constructor(private http:HttpClient) { }

  enquiry:Enquiry={
    eid: '',
    firstName: '',
    middleName: '',
    lastName: '',
    age: '',
    address: '',
    country: '',
    existingCustomer: '',
    email: '',
    mobileNo: '',
    prefferedContactTime: undefined,
    prefferedBranchCode: '',
    adharno: '',
    pancardNo: '',
    custType: '',
    cibilscore: ''
  }


  saveEnquiryDataDemo(e:Enquiry)
  {
    return this.http.post("http://localhost:9090/saveEnq",e);
  }

  getEnquiryDataDemo()
  {
    return this.http.get("http://localhost:9090/getAllEnquiryDetails");
  }
}
