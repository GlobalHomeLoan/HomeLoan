import { Component } from '@angular/core';
import { AccountDetails } from 'src/app/model/account-details';
import { AccountDetailsService } from 'src/app/shared/account-details.service';

@Component({
  selector: 'app-view-account-details',
  templateUrl: './view-account-details.component.html',
  styleUrls: ['./view-account-details.component.css']
})
export class ViewAccountDetailsComponent {

  constructor(public service:AccountDetailsService){}

account:AccountDetails[];

ngOnInit(): void 
{ 
this.service.getAccountDetailsDemo().subscribe((e:AccountDetails[])=>{
  this.account=e;
})

}
}
