import { Component } from '@angular/core';
import { Enquiry } from 'src/app/model/enquiry';
import { EnquiryService } from 'src/app/shared/enquiry.service';

@Component({
  selector: 'app-view-enquiry',
  templateUrl: './view-enquiry.component.html',
  styleUrls: ['./view-enquiry.component.css']
})
export class ViewEnquiryComponent 
{
constructor(public service:EnquiryService){}

enquiry:Enquiry[];
ngOnInit(): void {
 
this.service.getEnquiryDataDemo().subscribe((e:Enquiry[])=>{
  this.enquiry=e;
})
}
}
