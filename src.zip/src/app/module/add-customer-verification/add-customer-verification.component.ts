import { Component, OnInit } from '@angular/core';
import { CustomerVerification } from 'src/app/model/customer-verification';
import { CustomerVerificationService } from 'src/app/shared/customer-verification.service';

@Component({
  selector: 'app-add-customer-verification',
  templateUrl: './add-customer-verification.component.html',
  styleUrls: ['./add-customer-verification.component.css']
})
export class AddCustomerVerificationComponent implements OnInit {
  
  ngOnInit(): void {}

  constructor(public service:CustomerVerificationService){}

  saveCustomerVerificationData(e:CustomerVerification)
  {
    alert("data saved")
    this.service.saveCustomerVerificationDemo(e).subscribe();
    //window.location.reload();
  }
}
