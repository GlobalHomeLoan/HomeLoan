import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddCustomerVerificationComponent } from './add-customer-verification.component';

describe('AddCustomerVerificationComponent', () => {
  let component: AddCustomerVerificationComponent;
  let fixture: ComponentFixture<AddCustomerVerificationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddCustomerVerificationComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(AddCustomerVerificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
