import { Component, OnInit } from '@angular/core';
import { AccountDetails } from 'src/app/model/account-details';
import { AccountDetailsService } from 'src/app/shared/account-details.service';

@Component({
  selector: 'app-add-account-details',
  templateUrl: './add-account-details.component.html',
  styleUrls: ['./add-account-details.component.css']
})
export class AddAccountDetailsComponent implements OnInit {
  
  ngOnInit(): void {}

  constructor(public service:AccountDetailsService){}

  saveAccountDetails(e:AccountDetails)
  {
    alert("data saved")
    this.service.saveAccountDetailsDemo(e).subscribe();
    //window.location.reload();
  }

}
