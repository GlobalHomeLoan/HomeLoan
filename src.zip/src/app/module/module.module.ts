import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ModuleRoutingModule } from './module-routing.module';
import { EnquiryComponent } from './enquiry/enquiry.component';
import { SanctionComponent } from './sanction/sanction.component';
import { FormsModule } from '@angular/forms';
import { ViewEnquiryComponent } from './view-enquiry/view-enquiry.component';
import { ViewSanctionComponent } from './view-sanction/view-sanction.component';
import { AddAccountDetailsComponent } from './add-account-details/add-account-details.component';
import { ViewAccountDetailsComponent } from './view-account-details/view-account-details.component';
import { AddCustomerVerificationComponent } from './add-customer-verification/add-customer-verification.component';
import { ViewCustomerVerificationComponent } from './view-customer-verification/view-customer-verification.component';


@NgModule({
  declarations: [
    EnquiryComponent,
    SanctionComponent,
    ViewEnquiryComponent,
    ViewSanctionComponent,
    AddAccountDetailsComponent,
    ViewAccountDetailsComponent,
    AddCustomerVerificationComponent,
    ViewCustomerVerificationComponent
  ],
  imports: [
    CommonModule,
    ModuleRoutingModule,
    FormsModule
  ]
})
export class ModuleModule { }
