import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Enquiry } from 'src/app/model/enquiry';
import { EnquiryService } from 'src/app/shared/enquiry.service';

@Component({
  selector: 'app-enquiry',
  templateUrl: './enquiry.component.html',
  styleUrls: ['./enquiry.component.css']
})
export class EnquiryComponent implements OnInit {
  
  ngOnInit(): void {}

  constructor(public service:EnquiryService){}

  saveEnquiryData(e:Enquiry)
  {
    alert("data saved")
    this.service.saveEnquiryDataDemo(e).subscribe();
    window.location.reload();
  }

  


}
