import { Component, OnInit } from '@angular/core';
import { Email } from 'src/app/model/email';
import { Sanction } from 'src/app/model/sanction';
import { SanctionService } from 'src/app/shared/sanction.service';

@Component({
  selector: 'app-sanction',
  templateUrl: './sanction.component.html',
  styleUrls: ['./sanction.component.css']
})
export class SanctionComponent  implements OnInit {
  
  ngOnInit(): void {
   
  }

  constructor(public service:SanctionService){}

  saveSanctionData(s:Sanction)
  {
    alert("data saved")
    this.service.saveSanctionDataDemo(s).subscribe();
    window.location.reload();
  }


}
