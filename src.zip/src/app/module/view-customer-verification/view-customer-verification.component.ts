import { Component } from '@angular/core';
import { CustomerVerification } from 'src/app/model/customer-verification';
import { CustomerVerificationService } from 'src/app/shared/customer-verification.service';

@Component({
  selector: 'app-view-customer-verification',
  templateUrl: './view-customer-verification.component.html',
  styleUrls: ['./view-customer-verification.component.css']
})
export class ViewCustomerVerificationComponent 
{
  constructor(public service:CustomerVerificationService){}

customer:CustomerVerification[];

ngOnInit(): void 
{ 
this.service.getCustomerVerificationDemo().subscribe((e:CustomerVerification[])=>{
  this.customer=e;
})

}

}
