import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewCustomerVerificationComponent } from './view-customer-verification.component';

describe('ViewCustomerVerificationComponent', () => {
  let component: ViewCustomerVerificationComponent;
  let fixture: ComponentFixture<ViewCustomerVerificationComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewCustomerVerificationComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ViewCustomerVerificationComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
