import { Component } from '@angular/core';
import { Email } from 'src/app/model/email';
import { Sanction } from 'src/app/model/sanction';
import { SanctionService } from 'src/app/shared/sanction.service';


@Component({
  selector: 'app-view-sanction',
  templateUrl: './view-sanction.component.html',
  styleUrls: ['./view-sanction.component.css']
})
export class ViewSanctionComponent 
{
  constructor(public service:SanctionService){}

sanction:Sanction[];
ngOnInit(): void {
 
this.service.getSanctionDataDemo().subscribe((s:Sanction[])=>{
  this.sanction=s;
})
}


eml:Email[];
Em:Email={
  toMail: '',
  fromMail: '',
  subject: '',
  body: ''
}
saveMailData(s:Email)
{
  alert("mail sent")
  this.service.savemaildemo(s).subscribe();
  window.location.reload();

  //declare let Email: any;
  //model: Model = new Model();
 // Email.send({
   // Host : 'smtp.gmail.com',
    //Username : 'pritibhosale4444@gmail.com',
    //Password : 'hflydseawhlzkjtp',
    //To : 'pritibhosale7@gmail.com',
    //From : 'pritibhosale4444@gmail.com',
    //Subject : this.model.subject,
    //Body : `
    //<i>This is sent as a feedback from my resume page.</i> <br/> <b>Name: </b>${this.model.name} <br /> <b>Email: </b>${this.model.email}<br /> <b>Subject: </b>${this.model.subject}<br /> <b>Message:</b> <br /> ${this.model.message} <br><br> <b>~End of Message.~</b> `
    //}).then( message => {alert(message); f.resetForm(); } );
      
   // }
}

}
