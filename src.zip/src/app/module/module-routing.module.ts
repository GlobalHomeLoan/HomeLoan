import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EnquiryComponent } from './enquiry/enquiry.component';
import { ViewEnquiryComponent } from './view-enquiry/view-enquiry.component';
import { SanctionComponent } from './sanction/sanction.component';
import { ViewSanctionComponent } from './view-sanction/view-sanction.component';
import { AddAccountDetailsComponent } from './add-account-details/add-account-details.component';
import { ViewAccountDetailsComponent } from './view-account-details/view-account-details.component';
import { AddCustomerVerificationComponent } from './add-customer-verification/add-customer-verification.component';
import { ViewCustomerVerificationComponent } from './view-customer-verification/view-customer-verification.component';

const routes: Routes = [
  {path:'enquiry' ,component:EnquiryComponent},
  {path:'viewEnquiry',component:ViewEnquiryComponent},
  {path:'sanction' ,component:SanctionComponent},
  {path:'viewSanction' ,component:ViewSanctionComponent},
  {path:'addAccountDetails' ,component:AddAccountDetailsComponent},
  {path:'viewAccountDetails' ,component:ViewAccountDetailsComponent},
  {path:'AddCustomerVerification' ,component:AddCustomerVerificationComponent},
  {path:'ViewCustomerVerification' ,component:ViewCustomerVerificationComponent},
 
 
];

@NgModule({
  imports: [RouterModule.forChild(routes),],
  exports: [RouterModule]
})
export class ModuleRoutingModule { }
