import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  constructor(private router:Router) { }

  ngOnInit(): void {
  }

  navToAddEnquiry()
  {
     this.router.navigateByUrl("/module/enquiry")   
  }
  navToViewEnquiry()
  {
    this.router.navigateByUrl("/module/viewEnquiry")
  }

  navToAddSanction()
  {
    this.router.navigateByUrl("/module/sanction")
  }

  navToViewSanction()
  {
    this.router.navigateByUrl("/module/viewSanction")
  }

  navToAddAccountDetails()
  {
    this.router.navigateByUrl("/module/addAccountDetails")
  }

  navToViewAccountDetails()
  {
    this.router.navigateByUrl("/module/viewAccountDetails")
  }

  navToAddCustomerVerification()
  {
    this.router.navigateByUrl("/module/AddCustomerVerification")
  }

  navToViewCustomerVerification()
  {
    this.router.navigateByUrl("/module/ViewCustomerVerification")
  }

}
