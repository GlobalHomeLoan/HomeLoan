import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { EnquiryComponent } from './module/enquiry/enquiry.component';
import { SanctionComponent } from './module/sanction/sanction.component';
import { HomeComponent } from './home/home.component';

const routes: Routes = [
  {
    path:'',component:HomeComponent
  },
  
  {
    path:'module',loadChildren:()=>import("src/app/module/module.module").then(e=>e.ModuleModule)
  }

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
