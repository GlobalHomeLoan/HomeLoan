import { AccountDetails } from './account-details';

describe('AccountDetails', () => {
  it('should create an instance', () => {
    expect(new AccountDetails()).toBeTruthy();
  });
});
