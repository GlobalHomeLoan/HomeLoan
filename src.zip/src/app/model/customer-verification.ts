export class CustomerVerification 
{
    verificationId:number
	verificationDate:string
	status:string
	remarks:string
}
