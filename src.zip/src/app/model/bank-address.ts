export class BankAddress {
     bankAddrId:number
	 area:string
	 city:string
	 pin:string
	 state:string
	
}
