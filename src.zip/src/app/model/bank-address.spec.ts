import { BankAddress } from './bank-address';

describe('BankAddress', () => {
  it('should create an instance', () => {
    expect(new BankAddress()).toBeTruthy();
  });
});
