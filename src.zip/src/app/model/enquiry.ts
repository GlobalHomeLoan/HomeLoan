export class Enquiry {
    eid:any;
	firstName:string;
	middleName:string;
	lastName:string;
	age:any;
	address:string;
	country:string;
	existingCustomer:String;
	email:string;
	mobileNo:any;
	prefferedContactTime:any;
	prefferedBranchCode:string;
	adharno:string;
	pancardNo:string;
	custType:string;
	cibilscore:string;
}
