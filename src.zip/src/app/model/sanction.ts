export class Sanction {
    sanctionId:number
	sanctionDate:string
	applicantName:string
	contactDetails:string
	producthomeEquity:string
    loanAmtSanctioned:string
	interestType:string
	rateOfInterest:string
	loanTenure:string
	monthlyEmiAmount:string
	modeOfPayment:string
	remarks:string
	termsCondition:string
	status:string
}
