import { BankAddress } from "./bank-address"

export class AccountDetails 
{
     accountId:number
	 accountType:string
	 accountBalance:string
	 accountHolderName:string
	 accountStatus:string
     accountNumber:string
	 branchName:string
	 branchCode:string
	 branchType:string
	 iFSCcode:string
	 mICRcode:string
	 conatctNumber:string
	 email:string
     bankAddress:BankAddress
}
