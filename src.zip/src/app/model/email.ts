export class Email {
    toMail:string;
	fromMail:string;
	subject:string;
	body:string;

}
