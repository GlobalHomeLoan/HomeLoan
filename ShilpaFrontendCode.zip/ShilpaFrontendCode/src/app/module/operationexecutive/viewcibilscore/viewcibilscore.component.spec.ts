import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewcibilscoreComponent } from './viewcibilscore.component';

describe('ViewcibilscoreComponent', () => {
  let component: ViewcibilscoreComponent;
  let fixture: ComponentFixture<ViewcibilscoreComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewcibilscoreComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewcibilscoreComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
