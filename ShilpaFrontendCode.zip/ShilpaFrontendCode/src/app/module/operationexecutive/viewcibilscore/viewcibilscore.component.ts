import { Component, OnInit } from '@angular/core';
import { Cibil } from 'app/model/cibil';
import { CibilserviceService } from 'app/module/shared/cibilservice.service';

@Component({
  selector: 'app-viewcibilscore',
  templateUrl: './viewcibilscore.component.html',
  styleUrls: ['./viewcibilscore.component.css']
})
export class ViewcibilscoreComponent implements OnInit {

  constructor(public service:CibilserviceService) { }

  cl:Cibil[];
  ngOnInit(): void {
    this.service.getCibilData().subscribe((data:Cibil[])=>{
      this.cl=data;
    })
  }
/*  editData(cl:Cibil)
  {
    this.service.cibil=Object.assign({},cl);
   

  }
  deleteData(cl:Cibil)
  {
    this.service.deleteCibilData(cl).subscribe();
    window.location.reload();

  }*/


}
