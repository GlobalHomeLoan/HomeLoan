import { ComponentFixture, TestBed } from '@angular/core/testing';

import { OperationexecutiveComponent } from './operationexecutive.component';

describe('OperationexecutiveComponent', () => {
  let component: OperationexecutiveComponent;
  let fixture: ComponentFixture<OperationexecutiveComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ OperationexecutiveComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(OperationexecutiveComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
