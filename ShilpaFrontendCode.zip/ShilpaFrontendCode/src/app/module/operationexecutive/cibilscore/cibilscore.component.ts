import { Component, OnInit } from '@angular/core';
import { Cibil } from 'app/model/cibil';
import { CibilserviceService } from 'app/module/shared/cibilservice.service';

@Component({
  selector: 'app-cibilscore',
  templateUrl: './cibilscore.component.html',
  styleUrls: ['./cibilscore.component.css']
})
export class CibilscoreComponent implements OnInit {

  constructor(public service:CibilserviceService) { }
  saveData(cbl:Cibil)
  {

    this.service.saveCibilData(cbl).subscribe();
   
    window.location.reload();

   /*if(cbl.cibilScore>=700)
    {
      alert("We are glad to offer you loan . Your cibil score is "+cbl.cibilScore )
      this.service.saveCibilData(cbl).subscribe();
      window.location.reload();
    
   }
   else{
    alert("Sorry we cannot approve your loan as your cibil score is Too Low " +this.service.cbl.cibilScore )
    alert("Sorry we cannot approve your loan as your cibil score is Too Low " +cbl.cibilScore )
    
     window.location.reload();
     
   }*/
  }
 cibil:Cibil[];
  ngOnInit(): void {
    this.service.getCibilData().subscribe((data:Cibil[])=>{
     this.cibil=data;
    })
  }
 /* editData(cibil:Cibil)
  {
   this.service.cibil=Object.assign({},cibil);
  

  }
  deleteData(cibil:Cibil)
  {
    this.service.deleteCibilData(cibil).subscribe();
    window.location.reload();

  }*/


  


}
