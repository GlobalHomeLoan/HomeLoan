import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { DashboardComponent } from './dashboard/dashboard.component';
import { RouterModule, Routes } from '@angular/router';
import { ViewequiryComponent } from './viewequiry/viewequiry.component';

import { CibilscoreComponent } from './cibilscore/cibilscore.component';
import { FormsModule } from '@angular/forms';
import { OperationexecutiveComponent } from './operationexecutive.component';
import { ViewcibilscoreComponent } from './viewcibilscore/viewcibilscore.component';


const oerouting: Routes = [
  {path: 'oedash', component: DashboardComponent},
  {path:'oeenq',component:ViewequiryComponent},
 
  {path:'cibil',component:CibilscoreComponent},
  {path:'viewcibil',component:ViewcibilscoreComponent}
  
]
@NgModule({
  declarations: [DashboardComponent, ViewequiryComponent, CibilscoreComponent, OperationexecutiveComponent, ViewcibilscoreComponent],
  imports: [
    CommonModule,RouterModule.forChild(oerouting),FormsModule
  ]
})
export class OperationexecutiveModule { }
