import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-operationexecutive',
  templateUrl: './operationexecutive.component.html',
  styleUrls: ['./operationexecutive.component.css']
})
export class OperationexecutiveComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
