import { Component, OnInit } from '@angular/core';
import { Enquiry } from 'app/model/enquiry';
import { EnquiryService } from 'app/module/shared/enquiry.service';

@Component({
  selector: 'app-viewequiry',
  templateUrl: './viewequiry.component.html',
  styleUrls: ['./viewequiry.component.css']
})
export class ViewequiryComponent implements OnInit {

  constructor(public cs:EnquiryService) { }

  enquiry:Enquiry[];
  ngOnInit(): void {
   
  this.cs.getdata().subscribe((e:Enquiry[])=>{
    this.enquiry=e;
  })
  }
  
}
