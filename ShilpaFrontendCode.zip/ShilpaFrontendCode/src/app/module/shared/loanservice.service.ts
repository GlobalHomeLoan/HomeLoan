import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Currentloan } from 'app/model/currentloan';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class LoanserviceService {

  
  constructor(private http:HttpClient) { }
  loan:Currentloan={
    currentloanId: 0,
    currentloanNo: 0,
    emidetails: {
      emiID:0,
      emiAmountMonthly:0,
      nextEmiDueDate:'',
      previousEmiStatus:''
    },
    loanAmount: 0,
    rateOfInterest: '',
    tenure: '',
    totalAmounttobepaid: 0,
    processingFees: 0,
    totalInterest: 0,
    sanctionDate: '',
    bankaddress:{
      bankAddId:0,
      area:"",
      city:"",
      pin:0,
      state:""
    },
    remark: '',
    status: ''
  }
  saveLoanData(cl:Currentloan)
  {
    alert("calling save data!")
    return this.http.post("http://localhost:8889/saveCurrentLoanData",cl)
  }
  getLoanData():Observable<Currentloan[]>
  {
    return this.http.get<Currentloan[]>("http://localhost:8889/getCurrentLoanData")
  }
  editLoanData(cl:Currentloan)
  {
    return this.http.put("http://localhost:8889/updateCurrentLoanData/"+cl.currentloanId,cl)
  }
  deleteLoanData(cl:Currentloan)
  {
    return this.http.delete("http://localhost:8889/deleteCurrentLoanData/"+cl.currentloanId)
  }



}
