import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { DocumentRequired } from 'app/model/document-required';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DocumentrequiredService {

  constructor(public http:HttpClient) { }

  savedata(doc:any):Observable<DocumentRequired>
  {
     return this.http.post<DocumentRequired>("http://localhost:9500/upload",doc)
  }

  

}
