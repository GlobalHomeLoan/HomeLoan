import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CustomerDetails } from 'app/model/customer-details';


@Injectable({
  providedIn: 'root'
})
export class CustomerService {

  constructor(public http:HttpClient) { }

  cust:CustomerDetails={
    customerId: undefined,
    firstname: '',
    lastname: '',
    age: undefined,
    email: '',
    mobileNo: undefined,
    dob: '',
    customertype: '',
    adharcardNo: undefined,
    pancardNo: undefined,
    educationtype: '',
       localAddress: {
    lid:undefined,
    district:'',
    state:'',
    pincode:'',
    houseNo:undefined,
    streetName:'',
    country:'',
    areaName:'',
    cityName:'',
    },
    permanentAddress: 
    {
      pid:undefined,
      district:'',
      state:'',
      pincode:'',
      houseNo:undefined,
      streetName:'',
      country:'',
      areaName:'',
      cityName:'',
    },
    professionDetails: {
      professionid:undefined,
      employeeId:undefined,
      professionType:'',
      professionDesignation:'',
      professionSalary:undefined,
      totalExperience:undefined,
      officeAddress:
      {
      pid:undefined,
      district:'',
      state:'',
      pincode:'',
      houseNo:undefined,
      streetName:'',
      country:'',
      areaName:'',
      cityName:'',
      }
    },
    accountDetails: {
    accountId:undefined,
    accountType:'',
    bankaccountName:'',
    accountholderName:'',
    accountNo:undefined,
    accountIFSCcode:'',
    accountStatus:'',
    accountMICRcode:undefined,
    branchCode:undefined,
    branchName:'',
    },
    requiredLoanDetails:{
      loanid:undefined,
      loanNo:undefined,
      loanAmount:undefined,
      rateOfInterest:undefined,
      tenure:undefined,
      emiAmountPerMonth:undefined,
      totalAmountToBePaid:undefined,
    },
    previousLoanDetails:
    {
      ploanid:undefined,
      previousLoanAmount:undefined,
      previousLoanTenure:undefined,
      previousLoanPaidAmount:undefined,
      previousLoanRemainingAmount:undefined,
      previousLoanStatus:'',
      previousLoanBankDetails:{
        bankId:undefined,
        branchName:'',
        branchCode:undefined,
        bankAddress:'',
      }
    },
    propertyInfo: {
    propertyid:undefined,
    propertyType:'',
    propertyarea:undefined,
    propertyPrice:undefined,
    permanentAddress:{
      pid:undefined,
      district:'',
      state:'',
      pincode:'',
      houseNo:undefined,
      streetName:'',
      country:'',
      areaName:'',
      cityName:'',
      }
    },
    garrentorDetails:
    {
    garrentorid:undefined,
    garrentorName:'',
    garrentorDob:'',
    garrentorRelationWithCustomer:'',
    garrentorMobileNo:undefined,
    garrentorAdharcardNo:undefined,
    garrentorPancardNo:'',
    garrrentorJobDetails:'',
    garentorLocalAddress:'',
    garrentorPermanantAddress:'',
    }
    }
   

    savedata(cust:CustomerDetails)
    {
      return this.http.post("http://localhost:9500/saveCustomer",cust)
    }
    getdata()
    {
      return this.http.get("http://localhost:9500/getCustomer");
    }

  }


