import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Enquiry } from 'app/model/enquiry';

@Injectable({
  providedIn: 'root'
})
export class EnquiryService {

  constructor(public http:HttpClient) { }

  enquiry:Enquiry={
    id: 0,
    firstName: '',
    lastName: '',
    age: 0,
    email: '',
    mobileNo: '',
    dob: '',
    adharcardNo: '',
    pancardNo: '',
    status: '',
    cibilScore: 0
  }


  savedata(e:Enquiry)
  {
   return this.http.post("http://localhost:9500/saveEnquiry",e);
  }

  getdata()
  {
    return this.http.get("http://localhost:9500/getAllEnquiry");
  }
}
