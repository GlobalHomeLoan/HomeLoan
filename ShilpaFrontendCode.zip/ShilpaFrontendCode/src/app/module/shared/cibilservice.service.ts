import { HttpClient, HttpClientModule } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Cibil } from 'app/model/cibil';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CibilserviceService {

  constructor(private http:HttpClient) { }
  cbl:Cibil={
    cibilId: 0,
    date: '',
    pancardNo: '',
    cibilScore: 0
  }
  saveCibilData(cibil:Cibil)
  {
    alert("calling save data!")
    return this.http.post("http://localhost:8889/saveCibilData",cibil)
  }
  getCibilData():Observable<Cibil[]>
  {
    return this.http.get<Cibil[]>("http://localhost:8889/getCibilData")
  }
 /* editCibilData(c:Cibil)
  {
    return this.http.put("http://localhost:8889/updateCibilData/"+c.cibilId,c)
  }
  deleteCibilData(c:Cibil)
  {
    return this.http.delete("http://localhost:8889/deleteCibilData/"+c.cibilId)
  }*/

}