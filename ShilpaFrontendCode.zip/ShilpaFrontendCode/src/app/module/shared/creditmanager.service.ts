import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { DocumentRequired } from 'app/model/document-required';
import { Observable } from 'rxjs/internal/Observable';

@Injectable({
  providedIn: 'root'
})
export class CreditmanagerService {

  constructor(public http:HttpClient) { }

  getdata():Observable<any>
  {
    return this.http.get<DocumentRequired[]>("http://localhost:9500/getdocument")
  }
}
