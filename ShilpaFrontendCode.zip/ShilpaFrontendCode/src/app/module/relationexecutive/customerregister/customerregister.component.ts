import { Component, OnInit } from '@angular/core';
import { CustomerDetails } from 'app/model/customer-details';
import { CustomerService } from 'app/module/shared/customer.service';

@Component({
  selector: 'app-customerregister',
  templateUrl: './customerregister.component.html',
  styleUrls: ['./customerregister.component.css']
})
export class CustomerregisterComponent implements OnInit {

  constructor(public service:CustomerService) { }

  savedata(cust:CustomerDetails)
  {
    alert("saved method call")
    this.service.savedata(cust).subscribe();
   // window.location.reload();
  }
  ngOnInit(): void {
  }

}
