import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { DocumentRequired } from 'app/model/document-required';
import { DocumentrequiredService } from 'app/module/shared/documentrequired.service';

@Component({
  selector: 'app-document',
  templateUrl: './document.component.html',
  styleUrls: ['./document.component.css']
})
export class DocumentComponent implements OnInit {

  constructor(public cs:DocumentrequiredService,public fb:FormBuilder) { }

 
  docrequired:FormGroup;
  retriveform:any;
  selectedadharcard: any;
  selectedpancard: any;
  selectedlast3monthsalaryslip: any;
  selectedpropertyDocument: any;
  selectedbankCheque: any;
  selectedpassportsizePhoto: any;
  selectedlast6monthbankStatement: any;

  ngOnInit(): void {
    this.docrequired=this.fb.group({
    
    })
  }
  onselectedfile1(event:any)
   {
    this. selectedadharcard=event.target.files[0];
   }

   onselectedfile2(event:any)
   {
    this.selectedpancard=event.target.files[0];
   }

   onselectedfile3(event:any)
   {
    this.selectedlast3monthsalaryslip=event.target.files[0];
   }

   onselectedfile4(event:any)
   {
    this.selectedpropertyDocument=event.target.files[0];
   }

   onselectedfile5(event:any)
   {
    this.selectedbankCheque=event.target.files[0];
   }

   onselectedfile6(event:any)
   {
    this.selectedpassportsizePhoto=event.target.files[0];
   }

   onselectedfile7(event:any)
   {
    this.selectedlast6monthbankStatement=event.target.files[0];
   }

   savedata()
   {
     const d1=JSON.stringify(this.docrequired.value);
 
    const d2=new FormData();
 
    d2.append("adharcard",this.selectedadharcard);
    d2.append("pancard",this.selectedpancard);
    d2.append("last3monthsalaryslip",this.selectedlast3monthsalaryslip);
    d2.append("propertyDocument",this.selectedpropertyDocument);
    d2.append("bankCheque",this.selectedbankCheque);
    d2.append("passportsizePhoto",this.selectedpassportsizePhoto);
    d2.append("last6monthbankStatement",this.selectedlast6monthbankStatement);
  
 
    this.cs.savedata(d2).subscribe();
    console.log(" Method  uploaded")
   
    
 }
 
 

 
}
