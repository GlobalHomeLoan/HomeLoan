import { Component, OnInit } from '@angular/core';
import { DocumentRequired } from 'app/model/document-required';
import { CreditmanagerService } from 'app/module/shared/creditmanager.service';

@Component({
  selector: 'app-creditmanager',
  templateUrl: './creditmanager.component.html',
  styleUrls: ['./creditmanager.component.css']
})
export class CreditmanagerComponent implements OnInit {
  ngOnInit(): void {
  
  }

 
 
}
