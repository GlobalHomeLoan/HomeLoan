import { Component, OnInit } from '@angular/core';
import { CustomerDetails } from 'app/model/customer-details';
import { CustomerService } from 'app/module/shared/customer.service';

@Component({
  selector: 'app-view-customer',
  templateUrl: './view-customer.component.html',
  styleUrls: ['./view-customer.component.css']
})
export class ViewCustomerComponent implements OnInit {
  constructor(public cs:CustomerService) { }
  
  customer:CustomerDetails[];
  ngOnInit(): void {
   
  this.cs.getdata().subscribe((e:CustomerDetails[])=>{
    this.customer=e;
  })
  }

}
