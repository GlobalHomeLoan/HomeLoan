import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CreditmanagerComponent } from './creditmanager/creditmanager.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';
import { ViewDocumentComponent } from './view-document/view-document.component';
import { ViewCustomerComponent } from './view-customer/view-customer.component';

const routing: Routes = [
  {path: "credit", component:CreditmanagerComponent},
  {path: "viewdoc", component:ViewDocumentComponent },
  {path:'viewcust',component:ViewCustomerComponent}
  
];

@NgModule({
  declarations: [CreditmanagerComponent, ViewDocumentComponent, ViewCustomerComponent],
  imports: [
    CommonModule,RouterModule.forChild(routing)
  ]
})
export class CreditmanagerModule { }
