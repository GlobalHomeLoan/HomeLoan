import { Component, OnInit } from '@angular/core';
import { DocumentRequired } from 'app/model/document-required';
import { CreditmanagerService } from 'app/module/shared/creditmanager.service';

@Component({
  selector: 'app-view-document',
  templateUrl: './view-document.component.html',
  styleUrls: ['./view-document.component.css']
})
export class ViewDocumentComponent implements OnInit {

  constructor(public cs:CreditmanagerService) { }
  retriveform:any;
  ngOnInit(): void {
  }

  getdata()
  {
    this.cs.getdata().subscribe((d:DocumentRequired[])=>{
     this.retriveform=d;
    })
  }
}
