import { Component, OnInit } from '@angular/core';
import { Currentloan } from 'app/model/currentloan';
import { LoanserviceService } from 'app/module/shared/loanservice.service';

@Component({
  selector: 'app-addloandetails',
  templateUrl: './addloandetails.component.html',
  styleUrls: ['./addloandetails.component.css']
})
export class AddloandetailsComponent implements OnInit {

  constructor(public service:LoanserviceService) { }
  saveData(cl:Currentloan)
  {
   if(cl.currentloanId==0)
    {
      alert("data save successfully!")
      this.service.saveLoanData(cl).subscribe();
      window.location.reload();
    
   }
   else{
     alert("data updated successfully!")
     this.service.editLoanData(cl).subscribe();
     window.location.reload();
     
   }
  }
 cl:Currentloan[];
  ngOnInit(): void {
    this.service.getLoanData().subscribe((data:Currentloan[])=>{
     this.cl=data;
    })
  }
  editData(cl:Currentloan)
  {
   this.service.loan=Object.assign({},cl);
   this.service.loan.emidetails=Object.assign({},cl.emidetails);
    this.service.loan.bankaddress=Object.assign({},cl.bankaddress);

  }
  deleteData(cl:Currentloan)
  {
    this.service.deleteLoanData(cl).subscribe();
    window.location.reload();

  }


  

}
