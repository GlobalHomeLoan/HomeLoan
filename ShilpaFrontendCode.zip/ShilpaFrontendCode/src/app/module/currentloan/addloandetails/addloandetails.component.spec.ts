import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddloandetailsComponent } from './addloandetails.component';

describe('AddloandetailsComponent', () => {
  let component: AddloandetailsComponent;
  let fixture: ComponentFixture<AddloandetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddloandetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddloandetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
