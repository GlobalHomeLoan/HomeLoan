import { Component, OnInit } from '@angular/core';
import { Currentloan } from 'app/model/currentloan';
import { LoanserviceService } from 'app/module/shared/loanservice.service';

@Component({
  selector: 'app-viewloandetails',
  templateUrl: './viewloandetails.component.html',
  styleUrls: ['./viewloandetails.component.css']
})
export class ViewloandetailsComponent implements OnInit {

  constructor(public service:LoanserviceService) { }

  cl:Currentloan[];
  ngOnInit(): void {
    this.service.getLoanData().subscribe((data:Currentloan[])=>{
      this.cl=data;
    })
  }
  editData(cl:Currentloan)
  {
    this.service.loan=Object.assign({},cl);
    this.service.loan.emidetails=Object.assign({},cl.emidetails);
    this.service.loan.bankaddress=Object.assign({},cl.bankaddress);

  }
  deleteData(cl:Currentloan)
  {
    this.service.deleteLoanData(cl).subscribe();
    window.location.reload();

  }


}
