import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AddloandetailsComponent } from './addloandetails/addloandetails.component';
import { ViewloandetailsComponent } from './viewloandetails/viewloandetails.component';
import { RouterModule, Routes } from '@angular/router';
import { FormsModule } from '@angular/forms';

const routing: Routes = [
  {path: "addloan", component:AddloandetailsComponent},
  {path: "viewloan", component:ViewloandetailsComponent }
   
];


@NgModule({
  declarations: [AddloandetailsComponent, ViewloandetailsComponent],
  imports: [
    CommonModule,FormsModule ,RouterModule.forChild(routing)
  ]
})
export class CurrentloanModule { }
