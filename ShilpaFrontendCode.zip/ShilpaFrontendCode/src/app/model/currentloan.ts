import { BankAddress } from "./bank-address";
import { emidetails } from "./emidetails";

export class Currentloan {
    currentloanId:number;
    currentloanNo:number;
    emidetails:emidetails;	
    loanAmount:number;
    rateOfInterest:string;
    tenure:string;
    totalAmounttobepaid:number;
    processingFees:number;
    totalInterest:number;
    sanctionDate:string ;
    bankaddress:BankAddress;
    remark:string;
    status:string;
}
