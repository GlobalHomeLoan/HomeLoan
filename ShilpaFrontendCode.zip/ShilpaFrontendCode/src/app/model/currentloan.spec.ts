import { Currentloan } from './currentloan';

describe('Currentloan', () => {
  it('should create an instance', () => {
    expect(new Currentloan()).toBeTruthy();
  });
});
