import { PermanentAddress } from "./permanent-address";

export class PropertyInfo {
    propertyid:any;
    propertyType:string;
    propertyarea:any;
    propertyPrice:any;
    permanentAddress:PermanentAddress;
}
