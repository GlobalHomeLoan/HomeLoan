import { PermanentAddress } from "./permanent-address";

export class ProfessionDetails {
    professionid:number;
    employeeId:any;
    professionType:string;
    professionDesignation:string;
    professionSalary:any;
    totalExperience:any;
    officeAddress:PermanentAddress;
}
