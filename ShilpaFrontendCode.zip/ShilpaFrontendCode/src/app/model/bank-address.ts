export class BankAddress {
    bankAddId:number;
    area:string;
    city:string;
    pin:number;
    state:string;
}
