export class GarrentorDetails {
    garrentorid:any;
    garrentorName:string;
	garrentorDob:string;
	garrentorRelationWithCustomer:string;
    garrentorMobileNo:any;
    garrentorAdharcardNo:any;
	garrentorPancardNo:string;
	garrrentorJobDetails:string;
	garentorLocalAddress:string;
	garrentorPermanantAddress:string;
}
