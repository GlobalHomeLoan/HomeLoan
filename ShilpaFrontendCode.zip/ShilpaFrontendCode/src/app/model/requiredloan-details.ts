export class RequiredloanDetails {
    loanid:any;
	loanNo:any;
	loanAmount:any;
	rateOfInterest:any;
	tenure:any;
	emiAmountPerMonth:any;
	totalAmountToBePaid:any;
}
