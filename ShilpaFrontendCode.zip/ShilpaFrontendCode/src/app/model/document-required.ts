export class DocumentRequired {
    documentId:number;
    adharcard:[];
    pancard:[];
    last3monthsalaryslip:[];
    propertyDocument:[];
    bankCheque:[];
    passportsizePhoto:[];
    last6monthbankStatement:[];
}
