export class PreviousBankDetails {
    bankId:any;
    branchName:string;
    branchCode:any;
    bankAddress:string
}

