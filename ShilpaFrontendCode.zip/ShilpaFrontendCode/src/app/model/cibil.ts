export class Cibil {
    cibilId:number;
    date:string;
    pancardNo:string;
    cibilScore:number;
}
