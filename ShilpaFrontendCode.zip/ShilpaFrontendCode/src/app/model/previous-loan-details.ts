import { PreviousBankDetails } from "./previous-bank-details";

export class PreviousLoanDetails {

    ploanid:any;
    previousLoanAmount:any;
    previousLoanTenure:any;
    previousLoanPaidAmount:any;
    previousLoanRemainingAmount:any;
    previousLoanStatus:string;
    previousLoanBankDetails:PreviousBankDetails;
}
