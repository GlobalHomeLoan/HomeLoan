export class PermanentAddress {
    pid:any;
    district:string;
    state:string;
    pincode:any;
    houseNo:any;
    streetName:string;
    country:string;
    areaName:string;
    cityName:string;
}
