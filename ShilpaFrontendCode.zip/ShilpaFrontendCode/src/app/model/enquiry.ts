export class Enquiry {
     id:number;
	 firstName:String
	 lastName:String
	 age: number
	 email:String
	 mobileNo:any
	 dob:String;
	 adharcardNo:any
	 pancardNo:String
	 status:String
	 cibilScore:number;

}
