import { AccountDetails } from "./account-details";
import { GarrentorDetails } from "./garrentor-details";
import { LocalAddress } from "./local-address";
import { PermanentAddress } from "./permanent-address";
import { PreviousLoanDetails } from "./previous-loan-details";
import { ProfessionDetails } from "./profession-details";
import { PropertyInfo } from "./property-info";
import { RequiredloanDetails } from "./requiredloan-details";

export class CustomerDetails {
    customerId:any;
	firstname:string;
	lastname:string;
	age:any;
    email:string;
	mobileNo:any;
	dob:string;
	customertype:string;
	adharcardNo:any;
	pancardNo:any;
	educationtype:string;
	localAddress:LocalAddress;
	permanentAddress:PermanentAddress;
	professionDetails:ProfessionDetails;
	accountDetails:AccountDetails;
	requiredLoanDetails:RequiredloanDetails;
	previousLoanDetails:PreviousLoanDetails;
	propertyInfo:PropertyInfo;
	garrentorDetails:GarrentorDetails;

}
