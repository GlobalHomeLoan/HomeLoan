
export class Customer {
  studentId: any;
  firstName: String;
  lastName: String;
  mobNo: String;
  studentEmail: String;
  studentEvent: String;
  }


