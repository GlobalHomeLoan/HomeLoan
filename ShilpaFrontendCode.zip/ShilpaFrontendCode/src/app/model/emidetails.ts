export class emidetails {
    emiID :number;
    emiAmountMonthly:number;
    nextEmiDueDate:string;
    previousEmiStatus:string;
}
