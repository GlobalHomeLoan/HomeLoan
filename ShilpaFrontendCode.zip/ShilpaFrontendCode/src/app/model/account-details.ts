export class AccountDetails {

    accountId:any;
    accountType:string;
	bankaccountName:string;
	accountholderName:string;
	accountNo:any;
	accountIFSCcode:string;
	accountStatus:string;
	accountMICRcode:any;
	branchCode:any;
	branchName:string;
}
