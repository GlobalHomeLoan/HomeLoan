package com.main.exceptionHandler;

import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.main.exceptions.AccountDetailNotFoundException;
import com.main.exceptions.CustomerVerificationNotFoundException;
import com.main.exceptions.EnquiryNotFoundException;
import com.main.exceptions.SanctionNotFoundException;




@RestControllerAdvice
public class GlobalExceptionHandler 
{
	@ExceptionHandler(value = EnquiryNotFoundException.class)
	public String EnquiryNotFoundExceptionHandler()
	{
		return"Enquiry not found";
		
	}
	
	@ExceptionHandler(value = SanctionNotFoundException.class)
	public String SanctionNotFoundExceptionHandler()
	{
		return"Sanction not found";
		
	}
	
	@ExceptionHandler(value = AccountDetailNotFoundException.class)
	public String AccountDetailNotFoundExceptionHandler()
	{
		return"Account Details not found";
		
	}
	
	@ExceptionHandler(value = CustomerVerificationNotFoundException.class)
	public String CustomerVerificationNotFoundExceptionHandler()
	{
		return"Customer verification not found";
		
	}

}
