package com.main.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.main.model.SanctionLetter;

@Repository
public interface SanctionedRepository extends JpaRepository<SanctionLetter, Integer>  {

	
	
	
}
