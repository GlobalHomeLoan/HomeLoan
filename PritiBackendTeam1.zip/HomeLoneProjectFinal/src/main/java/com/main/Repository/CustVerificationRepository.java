package com.main.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.main.model.CustomerVerification;

@Repository
public interface CustVerificationRepository extends JpaRepository<CustomerVerification, Integer>  {

	
	
	
}
