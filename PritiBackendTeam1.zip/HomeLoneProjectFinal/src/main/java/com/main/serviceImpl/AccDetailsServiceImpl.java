package com.main.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import com.main.Repository.AccDetailRepository;
import com.main.exceptions.AccountDetailNotFoundException;
import com.main.exceptions.EnquiryNotFoundException;
import com.main.model.AccountDetails;
import com.main.model.EnquiryDetails;
import com.main.service.AccDetailsService;


@Service
public class AccDetailsServiceImpl implements AccDetailsService 
{
	@Autowired
	private AccDetailRepository accRepository;
	

	@Override
	public AccountDetails saveAccDetail(AccountDetails ac) 
	{
		AccountDetails accountDetails=accRepository.save(ac);
		return accountDetails;
	}
	
	@Override
	public List<AccountDetails> getalldata() {
		List<AccountDetails> aco=accRepository.findAll();
		return aco;
	}

	@Override
	public AccountDetails getallAccountDetailsrById(int accountId) 
	{
		 Optional<AccountDetails> optional=accRepository.findById(accountId);
			
			if(optional.isPresent())
			{
				AccountDetails account=optional.get();
				return account;
			}
			throw new AccountDetailNotFoundException();
		}
	}







