package com.main.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.main.Repository.CustVerificationRepository;
import com.main.exceptions.AccountDetailNotFoundException;
import com.main.exceptions.CustomerVerificationNotFoundException;
import com.main.model.AccountDetails;
import com.main.model.CustomerVerification;
import com.main.service.CustomerVerificationService;


@Service
public class CustomerVerificationserviceImpl implements CustomerVerificationService 
{
	
	@Autowired
	private CustVerificationRepository verificationrepo;
	

	@Override
	public CustomerVerification saveVerification(CustomerVerification cv) 
	{
		CustomerVerification cvn=verificationrepo.save(cv);
		return cvn;
	}

	@Override
	public List<CustomerVerification> GetCustVerification() 
	{
		List<CustomerVerification> CustVerification=verificationrepo.findAll();
		return CustVerification;
	}

	@Override
	public CustomerVerification getallCustomerVerificationById(int verificationId) 
	{
		 Optional<CustomerVerification> optional=verificationrepo.findById(verificationId);
			
			if(optional.isPresent())
			{
				CustomerVerification verify=optional.get();
				return verify;
			}
			throw new CustomerVerificationNotFoundException();
		}
	}


