package com.main.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import com.main.Repository.SanctionedRepository;
import com.main.exceptions.SanctionNotFoundException;
import com.main.model.Email;
import com.main.model.SanctionLetter;
import com.main.service.SanctionService;


@Service
public class SanctionServiceImpl implements SanctionService 
{
	
	@Autowired
	private SanctionedRepository sanctionrepository;
	
	@Autowired
	JavaMailSender sender;
	

	@Override
	public SanctionLetter saveSanctionLetter(SanctionLetter sc) {
		SanctionLetter scn=sanctionrepository.save(sc);
				return scn;
	}

	@Override
	public List<SanctionLetter> getallSanctionLetter() 
	{
		List<SanctionLetter> sanctionLetter=sanctionrepository.findAll();
		return sanctionLetter;
	}

	@Override
	public SanctionLetter getallSanctionLetterById(int sanctionId) 
	{
		 Optional<SanctionLetter> optional=sanctionrepository.findById(sanctionId);
			
			if(optional.isPresent())
			{
				SanctionLetter sanction=optional.get();
				return sanction;
			}
			throw new SanctionNotFoundException();
			
		
	}
	
	@Override
	public SanctionLetter updateSanctionLetter(SanctionLetter p) 
	{
		SanctionLetter sanction=sanctionrepository.save(p);	
			return sanction;
	}

	@Override
	public void deleteSanctionLetter(int sanctionId) 
	{
		sanctionrepository.deleteById(sanctionId);
		
	}
	

	@Override
	public void sendemail(Email e) {
		
		SimpleMailMessage msg=new SimpleMailMessage();
		msg.setTo(e.getToMail());
		msg.setFrom(e.getFromMail());
		msg.setSubject(e.getSubject());
		msg.setText(e.getBody());
		sender.send(msg);
		System.out.println("send");
	}

	

}
