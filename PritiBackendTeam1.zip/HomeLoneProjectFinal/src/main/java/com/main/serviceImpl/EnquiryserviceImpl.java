package com.main.serviceImpl;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.main.Repository.EnquiryRepository;
import com.main.exceptions.EnquiryNotFoundException;
import com.main.model.EnquiryDetails;
import com.main.service.EnquiryService;


@Service
public class EnquiryserviceImpl implements EnquiryService 
{
	@Autowired
	private EnquiryRepository repository;
	
	

	@Override
	public EnquiryDetails saveEnquiry(EnquiryDetails e) 
	{
		EnquiryDetails enq=repository.save(e);
		return enq;
	}

	@Override
	public List<EnquiryDetails> getallEnquiryDetails() 
	{
		List<EnquiryDetails> enquiryDetails=repository.findAll();
		return enquiryDetails;
		
	}

	@Override
	public EnquiryDetails getEnquiryDetailsById(int eid) 
	{
      Optional<EnquiryDetails> optional=repository.findById(eid);
		
		if(optional.isPresent())
		{
			EnquiryDetails enquiry=optional.get();
			return enquiry;
		}
		throw new EnquiryNotFoundException();
		
	}

}
