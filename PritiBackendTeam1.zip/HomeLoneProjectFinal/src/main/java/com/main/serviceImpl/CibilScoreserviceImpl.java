package com.main.serviceImpl;


import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.main.Repository.CibilScoreRepository;
import com.main.model.CibilScore;
import com.main.service.CibilScoreService;


@Service
public class CibilScoreserviceImpl implements CibilScoreService 
{
	@Autowired
	private CibilScoreRepository cbrepo;

	@Override
	public CibilScore saveCibilScore(CibilScore cb) 
	{
		Random random=new Random();
		cb.setCibilScore(random.nextInt(900-600)+600);
		CibilScore cibil=cbrepo.save(cb);
		return cibil;
	}

	@Override
	public List<CibilScore> getalldataCibilScore() {
		 List<CibilScore> cibil=cbrepo.findAll();
		return cibil;
	}
	

	
	
}
