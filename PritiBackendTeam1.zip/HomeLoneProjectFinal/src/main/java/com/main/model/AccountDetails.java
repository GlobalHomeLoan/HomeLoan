package com.main.model;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.validation.Valid;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

@Entity
public class AccountDetails {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int accountId;
	
	@NotBlank(message = "Please enter Proper Account Type")
	private String accountType;
	
	@Min(message="Please enter proper Account Balance",value = 1)
	private double accountBalance;
	
	@NotBlank(message = "Please enter Proper Account Holder Name")
	private String accountHolderName;
	
	@NotBlank(message = "Please enter Proper Account Status")
	private String accountStatus;
	
	@Min(message="Please enter proper Account Number",value = 1)
	private long accountNumber;
	
	@NotBlank(message = "Please enter Proper Branch Name")
	private String branchName;
	
	@NotBlank(message = "Please enter Proper Branch Code")
	private String branchCode;
	
	@NotBlank(message = "Please enter Proper Branch Type")
	private String branchType;
	
	@NotBlank(message = "Please enter Proper IFSC code")
	private String iFSCcode;
	
	@NotBlank(message = "Please enter Proper MICR code")
	private String mICRcode;
	
	@Min(message="Please enter proper Contact Number",value = 1)
	private long conatctNumber;
	
	@NotBlank(message = "Please enter Proper Email")
	private String email;
	
	@OneToOne( cascade = CascadeType.ALL) @Valid
	private BankAddress bankAddress;
	
	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	
	public String getAccountType() {
		return accountType;
	}
	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}
	public double getAccountBalance() {
		return accountBalance;
	}
	public void setAccountBalance(double accountBalance) {
		this.accountBalance = accountBalance;
	}
	public String getAccountHolderName() {
		return accountHolderName;
	}
	public void setAccountHolderName(String accountHolderName) {
		this.accountHolderName = accountHolderName;
	}
	public String getAccountStatus() {
		return accountStatus;
	}
	public void setAccountStatus(String accountStatus) {
		this.accountStatus = accountStatus;
	}
	public long getAccountNumber() {
		return accountNumber;
	}
	public void setAccountNumber(long accountNumber) {
		this.accountNumber = accountNumber;
	}
	public String getBranchName() {
		return branchName;
	}
	public void setBranchName(String branchName) {
		this.branchName = branchName;
	}
	public String getBranchCode() {
		return branchCode;
	}
	public void setBranchCode(String branchCode) {
		this.branchCode = branchCode;
	}
	public String getBranchType() {
		return branchType;
	}
	public void setBranchType(String branchType) {
		this.branchType = branchType;
	}
	
	
	public String getiFSCcode() {
		return iFSCcode;
	}
	public void setiFSCcode(String iFSCcode) {
		this.iFSCcode = iFSCcode;
	}
	public String getmICRcode() {
		return mICRcode;
	}
	public void setmICRcode(String mICRcode) {
		this.mICRcode = mICRcode;
	}
	public long getConatctNumber() {
		return conatctNumber;
	}
	public void setConatctNumber(long conatctNumber) {
		this.conatctNumber = conatctNumber;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public BankAddress getBankAddress() {
		return bankAddress;
	}
	public void setBankAddress(BankAddress bankAddress) {
		this.bankAddress = bankAddress;
	}
	
	
	
	
	
	

}
