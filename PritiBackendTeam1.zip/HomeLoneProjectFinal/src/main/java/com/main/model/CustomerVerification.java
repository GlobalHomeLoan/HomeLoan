package com.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;

@Entity
public class CustomerVerification 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	private int verificationId;
	
	@NotBlank(message = "Please enter Verification Date")
	private String verificationDate;
	
	@NotBlank(message = "Please enter Proper Status")
	private String status;
	
	@NotBlank(message = "Please enter Proper remark")
	private String remarks;
	
	public int getVerificationId() {
		return verificationId;
	}
	public void setVerificationId(int verificationId) {
		this.verificationId = verificationId;
	}
	public String getVerificationDate() {
		return verificationDate;
	}
	public void setVerificationDate(String verificationDate) {
		this.verificationDate = verificationDate;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	

}
