package com.main.model;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

@Entity
public class EnquiryDetails 
{
		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		private int eid;
		
		@NotBlank(message = "Please enter proper  name")
		private String firstName;
		
		@NotBlank(message = "Please enter proper middle name")
		private String middleName;
		
		@NotBlank(message = "Please enter proper lastname")
		private String lastName;
		
		@Min(message="Please enter proper age",value = 1)
		private int age;
		
		@NotBlank(message = "Please enter proper address")
		private String address;
		
		@NotBlank(message = "Please enter proper country")
		private String country;
		private String existingCustomer;
		
		@NotBlank(message = "Please enter proper Email ")
		private String email;
		
		@Min(message="Please enter proper age",value = 1)
		private long mobileNo;
		
		private String prefferedContactTime;
		
		@NotBlank(message = "Please enter proper Branch code")
		private String prefferedBranchCode;
		
		@NotBlank(message = "Please enter proper AdharCard Number")
		private String adharno;
		
		@NotBlank(message = "Please enter proper PanCard Number")
		private String pancardNo;
		
		private String custType;
		private String cibilscore;
		
		public String getCibilscore() {
			return cibilscore;
		}
		public void setCibilscore(String cibilscore) {
			this.cibilscore = cibilscore;
		}
		public int getEid() {
			return eid;
		}
		public void setEid(int eid) {
			this.eid = eid;
		}
		public String getFirstName() {
			return firstName;
		}
		public void setFirstName(String firstName) {
			this.firstName = firstName;
		}
		public String getMiddleName() {
			return middleName;
		}
		public void setMiddleName(String middleName) {
			this.middleName = middleName;
		}
		public String getLastName() {
			return lastName;
		}
		public void setLastName(String lastName) {
			this.lastName = lastName;
		}
		public int getAge() {
			return age;
		}
		public void setAge(int age) {
			this.age = age;
		}
		public String getAddress() {
			return address;
		}
		public void setAddress(String address) {
			this.address = address;
		}
		public String getCountry() {
			return country;
		}
		public void setCountry(String country) {
			this.country = country;
		}
		public String getExistingCustomer() {
			return existingCustomer;
		}
		public void setExistingCustomer(String existingCustomer) {
			this.existingCustomer = existingCustomer;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public long getMobileNo() {
			return mobileNo;
		}
		public void setMobileNo(long mobileNo) {
			this.mobileNo = mobileNo;
		}
		public String getPrefferedContactTime() {
			return prefferedContactTime;
		}
		public void setPrefferedContactTime(String prefferedContactTime) {
			this.prefferedContactTime = prefferedContactTime;
		}
		public String getPrefferedBranchCode() {
			return prefferedBranchCode;
		}
		public void setPrefferedBranchCode(String prefferedBranchCode) {
			this.prefferedBranchCode = prefferedBranchCode;
		}
		public String getAdharno() {
			return adharno;
		}
		public void setAdharno(String adharno) {
			this.adharno = adharno;
		}
		public String getPancardNo() {
			return pancardNo;
		}
		public void setPancardNo(String pancardNo) {
			this.pancardNo = pancardNo;
		}
		
		public String getCustType() {
			return custType;
		}
		public void setCustType(String custType) {
			this.custType = custType;
		}
	


}
