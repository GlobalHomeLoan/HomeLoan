package com.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

@Entity
public class BankAddress 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	private int bankAddrId;
	
	@NotBlank(message = "Please enter Proper Area")
	private String area;
	
	@NotBlank(message = "Please enter Proper City")
	private String city;
	
	@Min(message="Please enter proper Pincode",value = 1)
	private int pin;
	
	@NotBlank(message = "Please enter Proper State")
	private String state;
	
	
	public int getBankAddrId() {
		return bankAddrId;
	}
	public void setBankAddrId(int bankAddrId) {
		this.bankAddrId = bankAddrId;
	}
	public String getArea() 
	{
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public int getPin() {
		return pin;
	}
	public void setPin(int pin) {
		this.pin = pin;
	}
	public String getState() {
		return state;
	}
	public void setState(String state) {
		this.state = state;
	}
	
	

}
