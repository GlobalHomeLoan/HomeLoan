package com.main.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

@Entity
public class SanctionLetter 
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	
	private int sanctionId;
	
	@NotBlank(message = "Please enter proper Sanction Date")
	private String sanctionDate;
	
	@NotBlank(message = "Please enter proper Applicant Name")
	private String applicantName;
	
	@Min(message="Please enter Proper contact details",value = 1)
	private long contactDetails;
	
	@NotBlank(message = "Please enter proper Home Equity")
	private String producthomeEquity;
	
	@Min(message="Please enter proper Sanctioned Loan Amount",value = 1)
	private double loanAmtSanctioned;
	
	@NotBlank(message = "Please enter proper Interest Type")
	private String interestType;
	
	@NotBlank(message = "Please enter Rate Of Interest")
	private String rateOfInterest;
	
	@NotBlank(message = "Please enter proper Loan Tenure")
	private String loanTenure;
	
	@Min(message="Please enter proper Monthly Emi Amount",value = 1)
	private double monthlyEmiAmount;
	
	@NotBlank(message = "Please enter Mode of Payment")
	private String modeOfPayment;
	
	//@NotBlank(message = "Please enter proper remarks")
	private String remarks;
	
	private String termsCondition;
	
	//@NotBlank(message = "Please enter proper status")
	private String status;
	
	public int getSanctionId() {
		return sanctionId;
	}
	public void setSanctionId(int sanctionId) {
		this.sanctionId = sanctionId;
	}
	public String getSanctionDate() {
		return sanctionDate;
	}
	public void setSanctionDate(String sanctionDate) {
		this.sanctionDate = sanctionDate;
	}
	public String getApplicantName() {
		return applicantName;
	}
	public void setApplicantName(String applicantName) {
		this.applicantName = applicantName;
	}
	public long getContactDetails() {
		return contactDetails;
	}
	public void setContactDetails(long contactDetails) {
		this.contactDetails = contactDetails;
	}
	public String getProducthomeEquity() {
		return producthomeEquity;
	}
	public void setProducthomeEquity(String producthomeEquity) {
		this.producthomeEquity = producthomeEquity;
	}
	public double getLoanAmtSanctioned() {
		return loanAmtSanctioned;
	}
	public void setLoanAmtSanctioned(double loanAmtSanctioned) {
		this.loanAmtSanctioned = loanAmtSanctioned;
	}
	public String getInterestType() {
		return interestType;
	}
	public void setInterestType(String interestType) {
		this.interestType = interestType;
	}
	public String getRateOfInterest() {
		return rateOfInterest;
	}
	public void setRateOfInterest(String rateOfInterest) {
		this.rateOfInterest = rateOfInterest;
	}
	public String getLoanTenure() {
		return loanTenure;
	}
	public void setLoanTenure(String loanTenure) {
		this.loanTenure = loanTenure;
	}
	public double getMonthlyEmiAmount() {
		return monthlyEmiAmount;
	}
	public void setMonthlyEmiAmount(double monthlyEmiAmount) {
		this.monthlyEmiAmount = monthlyEmiAmount;
	}
	public String getModeOfPayment() {
		return modeOfPayment;
	}
	public void setModeOfPayment(String modeOfPayment) {
		this.modeOfPayment = modeOfPayment;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getTermsCondition() {
		return termsCondition;
	}
	public void setTermsCondition(String termsCondition) {
		this.termsCondition = termsCondition;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
}
