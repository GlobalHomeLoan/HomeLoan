package com.main.service;


import java.util.List;

import com.main.model.AccountDetails;
import com.main.model.CustomerVerification;
import com.main.model.EnquiryDetails;
import com.main.model.SanctionLetter;

public interface CustomerVerificationService {

	CustomerVerification saveVerification(CustomerVerification ac);

	List<CustomerVerification> GetCustVerification();

	CustomerVerification getallCustomerVerificationById(int verificationId);

	

	

}
