package com.main.service;



import java.util.List;

import com.main.model.EnquiryDetails;


public interface EnquiryService {

	EnquiryDetails saveEnquiry(EnquiryDetails e);

	List<EnquiryDetails> getallEnquiryDetails();

	EnquiryDetails getEnquiryDetailsById(int eid);


	

	

}
