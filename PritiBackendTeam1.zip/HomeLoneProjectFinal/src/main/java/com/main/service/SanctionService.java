package com.main.service;


import java.util.List;

import com.main.model.Email;
import com.main.model.SanctionLetter;

public interface SanctionService {

	SanctionLetter saveSanctionLetter(SanctionLetter ac);

	List<SanctionLetter> getallSanctionLetter();

	SanctionLetter getallSanctionLetterById(int sanctionId);

	SanctionLetter updateSanctionLetter(SanctionLetter p);

	void deleteSanctionLetter(int sanctionId);
	
	void sendemail(Email e);


	
	

	

}
