package com.main.service;

import java.util.List;

import com.main.model.CibilScore;

public interface CibilScoreService {

	CibilScore saveCibilScore(CibilScore cb);

	List<CibilScore> getalldataCibilScore();

	
	

	

}
