package com.main.service;


import java.util.List;

import com.main.model.AccountDetails;


public interface AccDetailsService {

	AccountDetails saveAccDetail(AccountDetails ac);
	
	List<AccountDetails> getalldata();

	AccountDetails getallAccountDetailsrById(int accountId);

	

	

	

}
