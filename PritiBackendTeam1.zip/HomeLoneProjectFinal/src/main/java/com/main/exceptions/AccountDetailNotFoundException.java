package com.main.exceptions;

public class AccountDetailNotFoundException extends RuntimeException {
	
	public AccountDetailNotFoundException()
	{	
	}
	
	public AccountDetailNotFoundException(String msg)
	{
		super(msg);
	}

}
