package com.main.exceptions;

public class CustomerVerificationNotFoundException extends RuntimeException {
	
	public CustomerVerificationNotFoundException()
	{	
	}
	
	public CustomerVerificationNotFoundException(String msg)
	{
		super(msg);
	}

}
