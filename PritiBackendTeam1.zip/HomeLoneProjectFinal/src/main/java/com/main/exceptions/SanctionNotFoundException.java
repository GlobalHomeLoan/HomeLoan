package com.main.exceptions;

public class SanctionNotFoundException extends RuntimeException {
	
	public SanctionNotFoundException()
	{	
	}
	
	public SanctionNotFoundException(String msg)
	{
		super(msg);
	}

}
