package com.main.exceptions;

public class EnquiryNotFoundException extends RuntimeException {
	
	public EnquiryNotFoundException()
	{	
	}
	
	public EnquiryNotFoundException(String msg)
	{
		super(msg);
	}

}
