package com.main.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import com.main.model.AccountDetails;
import com.main.model.CustomerVerification;
import com.main.service.CustomerVerificationService;
@CrossOrigin("*")
@RestController
public class CustomerVerificationController 
{
	@Autowired
	private CustomerVerificationService service;
	
	@PostMapping("/saveVerification")
	public String saveVerification(@Valid @RequestBody CustomerVerification ac)
	{
		CustomerVerification acc=service.saveVerification(ac);
		return " data saved successfully";
		
	}
	
	@GetMapping("/getAllCustVerification")
	public List<CustomerVerification> getalldata()
	{
		List<CustomerVerification> CustVerification=service.GetCustVerification();
		return CustVerification;
	}
	
	@GetMapping("/getAllCustVerification/{verificationId}")
	public CustomerVerification getallCustomerVerificationById(@PathVariable int verificationId)
	{
		CustomerVerification account=service.getallCustomerVerificationById(verificationId);
		return account;
	}
	
	@ResponseStatus(HttpStatus.BAD_REQUEST)
	@ExceptionHandler(MethodArgumentNotValidException.class)
	public Map<String, String> handleValidationExceptions(
	  MethodArgumentNotValidException ex) {
	    Map<String, String> errors = new HashMap<>();
	    ex.getBindingResult().getAllErrors().forEach((error) -> {
	        String fieldName = ((FieldError) error).getField();
	        String errorMessage = error.getDefaultMessage();
	        errors.put(fieldName, errorMessage);
	    });
	    return errors;
	}

}
